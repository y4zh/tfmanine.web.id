// --- Global Variables ---
let currentFilter = null;

// --- Helper Functions ---

// Filter routes by mode (Index Page)
function filterRoute(mode) {
    currentFilter = mode;
    const section = document.getElementById('route-list-section');
    const container = document.getElementById('route-list');
    const title = document.getElementById('route-list-title');
    const count = document.getElementById('route-count');

    // Clear active states
    document.querySelectorAll('.category-btn').forEach(btn => {
        btn.classList.remove('active', 'border-primary');
    });

    // Set active state
    const activeBtn = document.querySelector(`[data-mode="${mode}"]`);
    if (activeBtn) {
        activeBtn.classList.add('active', 'border-primary');
    }

    // Filter routes
    let filteredRoutes = [];
    let titleText = 'Daftar Rute';

    if (mode === 'brt') {
        // For Transjakarta, show both BRT and Non-BRT
        filteredRoutes = appData.routes.filter(r => r.mode === 'brt' || r.mode === 'nbrt');
        titleText = 'Rute Transjakarta';
    } else if (mode === 'mikro') {
        // Mikrotrans includes rusun routes - sort so rusun is first
        filteredRoutes = appData.routes.filter(r => r.mode === 'mikro');
        filteredRoutes.sort((a, b) => {
            if (a.subtype === 'rusun' && b.subtype !== 'rusun') return -1;
            if (a.subtype !== 'rusun' && b.subtype === 'rusun') return 1;
            return 0;
        });
        titleText = 'Rute Mikrotrans & Rusun';
    } else if (mode === 'krl') {
        filteredRoutes = appData.routes.filter(r => r.id === 'KRL');
        titleText = 'KRL Commuter Line';
    } else if (mode === 'lrt') {
        filteredRoutes = appData.routes.filter(r => r.id === 'LRT');
        titleText = 'LRT Jabodebek';
    } else {
        filteredRoutes = appData.routes.filter(r => r.mode === mode);
    }

    title.textContent = titleText;
    count.textContent = `(${filteredRoutes.length} rute)`;

    // Generate route cards
    container.innerHTML = filteredRoutes.map(route => `
        <div class="route-card bg-white rounded-xl p-4 shadow-sm cursor-pointer border border-gray-100" onclick="openDetail('${route.id}')">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <span class="text-white text-sm font-bold px-3 py-1.5 rounded-lg" style="background-color: ${route.badgeColor || '#0072bc'}">${route.code}</span>
                    <div>
                        <div class="flex items-center space-x-2">
                            <h3 class="font-semibold text-gray-800">${route.name}</h3>
                            ${route.subtype === 'rusun' ? '<span class="bg-green-100 text-green-700 text-xs font-bold px-2 py-0.5 rounded">RUSUN</span>' : ''}
                        </div>
                    </div>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                </svg>
            </div>
        </div>
    `).join('');

    // Show section
    section.classList.remove('hidden');
    section.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Clear filter (Index Page)
function clearFilter() {
    currentFilter = null;
    const section = document.getElementById('route-list-section');
    if (section) section.classList.add('hidden');

    document.querySelectorAll('.category-btn').forEach(btn => {
        btn.classList.remove('active', 'border-primary');
    });
}

// Initialize guides (Index Page)
function initGuides() {
    const container = document.getElementById('guides-container');
    if (!container) return;

    container.innerHTML = appData.guides.map((guide, index) => `
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <button onclick="toggleAccordion(${index})" class="w-full px-4 py-4 flex items-center justify-between text-left hover:bg-gray-50 transition-colors">
                <div class="flex items-center space-x-3">
                    <span class="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center text-orange-600 font-bold text-sm">${index + 1}</span>
                    <span class="font-semibold text-gray-800">${guide.title}</span>
                </div>
                <svg id="accordion-icon-${index}" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-gray-400 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                </svg>
            </button>
            <div id="accordion-content-${index}" class="accordion-content">
                <div class="px-4 pb-4 pt-2 border-t border-gray-100">
                    <ol class="space-y-3 font-data">
                        ${guide.steps.map((step, stepIndex) => `
                            <li class="flex items-start space-x-3">
                                <span class="flex-shrink-0 w-6 h-6 bg-primary/10 text-primary rounded-full flex items-center justify-center text-xs font-bold">${stepIndex + 1}</span>
                                <span class="text-gray-700 text-sm leading-relaxed">${step.replace(/\*\*(.*?)\*\*/g, '<strong class="text-primary font-semibold">$1</strong>')}</span>
                            </li>
                        `).join('')}
                    </ol>
                </div>
            </div>
        </div>
    `).join('');
}

// Toggle accordion (Index Page)
function toggleAccordion(index) {
    const content = document.getElementById(`accordion-content-${index}`);
    const icon = document.getElementById(`accordion-icon-${index}`);

    if (content && icon) {
        content.classList.toggle('open');
        icon.style.transform = content.classList.contains('open') ? 'rotate(180deg)' : 'rotate(0)';
    }
}

// Open detail page (Shared)
function openDetail(routeId) {
    const route = appData.routes.find(r => r.id === routeId);
    if (route) {
        const slug = route.code.toLowerCase().replace(/\s+/g, '-').replace(/[()]/g, '');
        // Works both locally and on server
        window.location.href = 'route-detail.html?rute=' + slug;
    }
}

// Go back (Shared)
function goBack() {
    window.location.href = 'index.html';
}

// Get route slug (Detail Page)
function getRouteSlug() {
    // Check URL path first (e.g., /rute/jak-85)
    const pathMatch = window.location.pathname.match(/\/rute\/([a-zA-Z0-9-]+)/);
    if (pathMatch) return pathMatch[1];

    // Fallback to query parameter (e.g., ?rute=jak-85)
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('rute');
}

// Get route data by slug (Detail Page)
function getRouteData(slug) {
    if (!slug) return null;
    return appData.routes.find(route => {
        const routeSlug = route.code.toLowerCase().replace(/\s+/g, '-').replace(/[()]/g, '');
        return routeSlug === slug.toLowerCase();
    });
}

// Get mode label (Detail Page)
function getModeLabel(mode) {
    const labels = {
        'brt': { text: 'Transjakarta BRT', bg: 'bg-red-100', color: 'text-red-600' },
        'nbrt': { text: 'Transjakarta Non-BRT', bg: 'bg-orange-100', color: 'text-orange-600' },
        'mikro': { text: 'Mikrotrans', bg: 'bg-blue-100', color: 'text-blue-600' },
        'rusun': { text: 'Rusun', bg: 'bg-green-100', color: 'text-green-600' },
        'rail': { text: 'KRL / LRT', bg: 'bg-purple-100', color: 'text-purple-600' }
    };
    return labels[mode] || { text: mode, bg: 'bg-gray-100', color: 'text-gray-600' };
}

// Render detail page (Detail Page)
function renderDetail() {
    const routeSlug = getRouteSlug();

    if (!routeSlug) {
        window.location.href = 'index.html';
        return;
    }

    const route = getRouteData(routeSlug);

    if (!route) {
        window.location.href = 'index.html';
        return;
    }

    // Update header
    const headerCode = document.getElementById('header-code');
    if (headerCode) headerCode.textContent = route.code;

    // Update route card badge
    const badge = document.getElementById('route-badge');
    if (badge) {
        badge.textContent = route.code;
        if (route.badgeColor) {
            badge.style.backgroundColor = route.badgeColor;
        }
    }

    // Update name
    const routeName = document.getElementById('route-name');
    if (routeName) routeName.textContent = route.name;

    // Mode badge
    const modeInfo = getModeLabel(route.mode);
    const routeMode = document.getElementById('route-mode');
    if (routeMode) {
        routeMode.innerHTML = `
            <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${modeInfo.bg} ${modeInfo.color}">
                ${modeInfo.text}
            </span>
        `;
    }

    // Info grid
    const routeTarif = document.getElementById('route-tarif');
    if (routeTarif) routeTarif.textContent = route.tarif;

    const routeJam = document.getElementById('route-jam');
    if (routeJam) routeJam.textContent = route.jam;

    // Stops list
    const stopsList = document.getElementById('stops-list');
    if (stopsList) {
        stopsList.innerHTML = route.stops.map((stop, index) => `
            <div class="flex items-start space-x-3 p-3 bg-gray-50 rounded-xl">
                <span class="flex-shrink-0 w-8 h-8 bg-accent/10 text-accent rounded-full flex items-center justify-center text-sm font-bold">${index + 1}</span>
                <span class="text-gray-700 font-data pt-1">${stop}</span>
            </div>
        `).join('');
    }

    // Map section
    const mapSection = document.getElementById('map-section');
    if (mapSection) {
        if (route.isPdf && route.mapImage) {
            // PDF link
            mapSection.innerHTML = `
                <a href="${route.mapImage}" target="_blank" rel="noopener noreferrer"
                    class="flex items-center justify-center space-x-3 bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-600/90 text-white font-bold py-4 px-6 rounded-xl transition-all shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <span>Buka Peta PDF</span>
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                    </svg>
                </a>
            `;
        } else if (route.mapImage) {
            // Image
            mapSection.innerHTML = `
                <div class="relative rounded-xl overflow-hidden bg-gray-100">
                    <img src="${route.mapImage}" alt="Peta Rute ${route.code}" class="w-full h-auto object-contain"
                        onerror="this.parentElement.innerHTML='<div class=\\'p-8 text-center text-gray-500\\'>Gambar tidak tersedia</div>'"
                        loading="lazy">
                    <a href="${route.mapImage}" target="_blank" rel="noopener noreferrer"
                        class="absolute bottom-3 right-3 bg-white/90 backdrop-blur-sm hover:bg-white text-gray-700 font-medium py-2 px-4 rounded-lg shadow-lg text-sm flex items-center space-x-2 transition-colors">
                        <span>Perbesar</span>
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" fill="none" viewBox="0 0 24 24"
                            stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                        </svg>
                    </a>
                </div>
            `;
        } else {
            // No map
            mapSection.innerHTML = `
                <div class="flex flex-col items-center justify-center p-8 bg-gray-50 rounded-xl text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-16 h-16 text-gray-300 mb-3" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                            d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                    </svg>
                    <p class="text-gray-500 font-medium">Peta tidak tersedia</p>
                    <p class="text-gray-400 text-sm mt-1">Silakan cek website Transjakarta untuk info lebih lanjut</p>
                </div>
            `;
        }
    }

    // Update page title
    document.title = `${route.code} - ${route.name} | TF MANINE`;
}


// --- Initialization ---

document.addEventListener('DOMContentLoaded', () => {
    // Check if we are on the index page (by checking for guides-container)
    if (document.getElementById('guides-container')) {
        initGuides();

        // Clean URL - remove index.html from URL display
        if (window.location.pathname.endsWith('index.html')) {
            const cleanUrl = window.location.pathname.replace('index.html', '');
            window.history.replaceState({}, document.title, cleanUrl || '/');
        }
    }

    // Check if we are on the detail page (by checking for header-code)
    if (document.getElementById('header-code')) {
        renderDetail();

        // Clean URL for detail page
        const routeSlug = getRouteSlug();
        if (routeSlug && window.location.search.includes('rute=')) {
            const cleanUrl = '/rute/' + routeSlug;
            window.history.replaceState({}, document.title, cleanUrl);
        }
    }
});
