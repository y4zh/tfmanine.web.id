const appData = {
    locations: [
        // School - Blue marker
        { name: "MAN 9 Jakarta", type: "school", coords: [106.910491, -6.241088], desc: "Jl. Hj Dogol No 54, Pondok Bambu" },

        // Transit stations - Orange markers
        { name: "Stasiun Buaran", type: "train", coords: [106.9231, -6.2153], desc: "Akses KRL Commuterline Lin Cikarang" },
        { name: "Halte Simpang Buaran", type: "brt", coords: [106.9242, -6.2158], desc: "Transit ke Koridor 11" },
        { name: "LRT Jatibening Baru", type: "lrt", coords: [106.9265, -6.2570], desc: "Akses LRT Jabodebek Lin Bekasi (BK)" },

        // Bus stops near MAN 9 - Green markers with walking time info
        { name: "Rusun Pondok Bambu", type: "busstop", coords: [106.910853, -6.241690], desc: "11P (Walikota Jakarta Timur), JAK 85 (Bintara)", walkTime: 1, distance: 50 },
        { name: "Puskesmas Duren Sawit", type: "busstop", coords: [106.910906, -6.241853], desc: "JAK 85 (Cipinang Indah)", walkTime: 2, distance: 80 },
        { name: "Jln. Teluk Mandar 1", type: "busstop", coords: [106.909881, -6.238719], desc: "11P (Walikota Jakarta Timur), JAK 02 (Duren Sawit), JAK 85 (Bintara)", walkTime: 5, distance: 400 },
        { name: "Jln. Teluk Mandar 2", type: "busstop", coords: [106.910088, -6.238954], desc: "11P (Rusun Pondok Bambu), JAK 02 (Kampung Melayu), JAK 85 (Bintara)", walkTime: 4, distance: 350 },

        // ========== AREA BUS STOPS (Gray/Black markers) ==========

        // Area Pahlawan Revolusi - Kalimalang
        { name: "Yayasan Perguruan Rakyat 1", type: "busstop_area", coords: [106.89865261169159, -6.22863383065942], desc: "4F (Pinang Ranti), JAK 42 (Pondok Kelapa)" },
        { name: "Yayasan Perguruan Rakyat 2", type: "busstop_area", coords: [106.8986294347656, -6.228387594821946], desc: "4F (Pulo Gadung), JAK 42 (Kampung Melayu), JAK 74 (Cipinang Muara)" },
        { name: "Kantor Pos Pondok Bambu", type: "busstop_area", coords: [106.89738539834836, -6.231891954360357], desc: "4F (Pinang Ranti)" },
        { name: "Pajak dan Retribusi Duren Sawit", type: "busstop_area", coords: [106.89767573778508, -6.230972623102336], desc: "4F (Pulo Gadung)" },
        { name: "RSIA Bunda Aliyah 1", type: "busstop_area", coords: [106.89658728511345, -6.233273296687227], desc: "4F (Pinang Ranti)" },
        { name: "RSIA Bunda Aliyah 2", type: "busstop_area", coords: [106.89651592396815, -6.233165020957645], desc: "4F (Pulo Gadung)" },
        { name: "Sbr. Beacukai Pondok Bambu", type: "busstop_area", coords: [106.89745488642193, -6.235849505778705], desc: "4F (Pulo Gadung)" },
        { name: "Komplek Beacukai Pondok Bambu", type: "busstop_area", coords: [106.89757738695754, -6.235849769190579], desc: "4F (Pinang Ranti)" },
        { name: "Sekolah Pusaka", type: "busstop_area", coords: [106.89835497939647, -6.236911696841331], desc: "4F (Pinang Ranti)" },
        { name: "SMAN 61", type: "busstop_area", coords: [106.89820859922939, -6.236911696841331], desc: "4F (Pulo Gadung)" },
        { name: "Simpang Pahlawan Revolusi 1", type: "busstop_area", coords: [106.89942637136932, -6.238650474577929], desc: "4F (Pulo Gadung), JAK 02 (Duren Sawit)" },
        { name: "Simpang Pahlawan Revolusi 2", type: "busstop_area", coords: [106.89939659259336, -6.238355683703602], desc: "4F (Pinang Ranti), JAK 02 (Kampung Melayu)" },
        { name: "Jln. Keamanan", type: "busstop_area", coords: [106.89984079267472, -6.239169750159575], desc: "4F (Pinang Ranti), JAK 02 (Kampung Melayu)" },
        { name: "Simpang Pondok Bambu Batas 3", type: "busstop_area", coords: [106.90095873757926, -6.241234513060123], desc: "4F (Pulo Gadung), JAK 02 (Duren Sawit)" },
        { name: "Simpang Pondok Bambu Batas 4", type: "busstop_area", coords: [106.90108157503, -6.241275216188863], desc: "4F (Pinang Ranti), JAK 02 (Kampung Melayu)" },
        { name: "Jln. Damai", type: "busstop_area", coords: [106.90184837852652, -6.242739293320024], desc: "4F (Pulo Gadung)" },
        { name: "Sbr. Jln. Damai", type: "busstop_area", coords: [106.90194764111298, -6.242738059895372], desc: "4F (Pinang Ranti)" },
        { name: "Jln. Masjid Al Wustho", type: "busstop_area", coords: [106.90492992471597, -6.245285396504473], desc: "4F (Pinang Ranti), JAK 35 (Pangkalan Jati)" },
        { name: "Simpang Kalimalang", type: "busstop_area", coords: [106.90506349194635, -6.245521799914609], desc: "4F (Pulo Gadung)" },
        { name: "Simpang Pahlawan Revolusi Kalimalang", type: "busstop_area", coords: [106.90576553436132, -6.245570375952437], desc: "JAK 35 (Pangkalan Jati), JAK 85 (Cipinang Indah)" },
        { name: "RS Harum", type: "busstop_area", coords: [106.90958643116758, -6.2478209476815705], desc: "4F (Pinang Ranti), 7P (Cawang Cililitan), JAK 35 (Rawamangun), JAK 84 (Kampung Melayu), JAK 85 (Cipinang Indah)" },
        { name: "Pangkalan Jati 1", type: "busstop_area", coords: [106.90837009540422, -6.246799348031465], desc: "7P (Pondok Kelapa), JAK 35 (Pangkalan Jati), JAK 84 (Kapin), JAK 85 (Cipinang Indah)" },
        { name: "Pangkalan Jati 2", type: "busstop_area", coords: [106.90776904285194, -6.247255961428696], desc: "7P (Cawang Cililitan), JAK 35 (Rawamangun), JAK 84 (Kampung Melayu)" },
        { name: "Taman Pangkalan Jati Kalimalang", type: "busstop_area", coords: [106.90529804904226, -6.245996225625063], desc: "7P (Pondok Kelapa), JAK 35 (Rawamangun), JAK 84 (Kapin), JAK 85 (Bintara)" },
        { name: "Pospol Makasar", type: "busstop_area", coords: [106.9062444217672, -6.246899738244128], desc: "4F (Pulo Gadung), 7P (Cawang Cililitan), JAK 35 (Rawamangun), JAK 84 (Kampung Melayu), JAK 85 (Cipinang Indah)" },
        { name: "Pangkalan Jati", type: "busstop_area", coords: [106.90754646390369, -6.247619232116976], desc: "4F (Pinang Ranti), JAK 35 (Rawamangun)" },
        { name: "Naga Jatiwaringin", type: "busstop_area", coords: [106.90781893465356, -6.248388151092027], desc: "4F (Pulo Gadung), JAK 35 (Rawamangun)" },
        { name: "Megatama", type: "busstop_area", coords: [106.9104836453775, -6.247260872745004], desc: "7P (Pondok Kelapa), JAK 35 (Pangkalan Jati), JAK 84 (Kapin), JAK 85 (Cipinang Indah)" },
        { name: "Kav. Agraria Duren Sawit", type: "busstop_area", coords: [106.91201203551618, -6.247703000935738], desc: "7P (Pondok Kelapa), JAK 35 (Pangkalan Jati), JAK 84 (Kapin), JAK 85 (Cipinang Indah)" },

        // Area Duren Sawit - BKT
        { name: "Taman UT Aheme", type: "busstop_area", coords: [106.92258849203223, -6.227737058504703], desc: "11P (Rusun Pondok Bambu), 11Q (Kampung Melayu via BKT)" },
        { name: "Masjid Jami Nurul Ain 2", type: "busstop_area", coords: [106.91942806494298, -6.227862484382258], desc: "11P (Rusun Pondok Bambu), 11Q (Kampung Melayu via BKT)" },
        { name: "Masjid Jami Nurul Ain 1", type: "busstop_area", coords: [106.91976522020691, -6.227724659305376], desc: "11P (Walikota Jakarta Timur), 11Q (Pulo Gebang via BKT)" },
        { name: "Jln. Swadaya Raya", type: "busstop_area", coords: [106.91743664315385, -6.228153796363687], desc: "11P (Walikota Jakarta Timur), 11Q (Pulo Gebang via BKT), JAK 39 (Kalimalang)" },
        { name: "Sbr. Swadaya Raya", type: "busstop_area", coords: [106.91632513214867, -6.22857753826811], desc: "11P (Rusun Pondok Bambu), 11Q (Kampung Melayu via BKT), JAK 42 (Kampung Melayu)" },
        { name: "Jln. Serdang", type: "busstop_area", coords: [106.91456679000049, -6.228892028821094], desc: "11P (Walikota Jakarta Timur), 11Q (Pulo Gebang via BKT), JAK 39 (Duren Sawit), JAK 42 (Pondok Kelapa)" },
        { name: "Jln. Kel. Raya", type: "busstop_area", coords: [106.91434418897317, -6.229106788604358], desc: "11P (Rusun Pondok Bambu), 11Q (Kampung Melayu via BKT), JAK 02 (Duren Sawit), JAK 26 (Rawamangun), JAK 42 (Kampung Melayu)" },
        { name: "Masjid Jami Al Barkah 1", type: "busstop_area", coords: [106.91211840633106, -6.229398784696151], desc: "11P (Walikota Jakarta Timur), 11Q (Pulo Gebang via BKT), JAK 42 (Pondok Kelapa)" },
        { name: "Masjid Jami Al Barkah 2", type: "busstop_area", coords: [106.9122759555198, -6.2295366093335325], desc: "11P (Rusun Pondok Bambu), 11Q (Kampung Melayu via BKT), JAK 02 (Duren Sawit), JAK 26 (Rawamangun), JAK 42 (Kampung Melayu)" },
        { name: "Baladewa Residence", type: "busstop_area", coords: [106.91036719641446, -6.229637077176653], desc: "11P (Walikota Jakarta Timur), 11Q (Pulo Gebang via BKT), JAK 42 (Pondok Kelapa)" },
        { name: "RS Duren Sawit", type: "busstop_area", coords: [106.90968591533799, -6.229770395681205], desc: "11Q (Kampung Melayu via BKT), JAK 26 (Rawamangun), JAK 35 (Rawamangun), JAK 42 (Kampung Melayu)" },
        { name: "Komplek Abadi 2", type: "busstop_area", coords: [106.90811386607544, -6.229721567389249], desc: "11Q (Kampung Melayu via BKT), JAK 26 (Rawamangun), JAK 35 (Rawamangun), JAK 42 (Kampung Melayu)" },
        { name: "Komplek Abadi 1", type: "busstop_area", coords: [106.90791538261222, -6.229588248872304], desc: "11Q (Pulo Gebang via BKT), JAK 26 (Duren Sawit), JAK 35 (Pangkalan Jati), JAK 42 (Pondok Kelapa)" },
        { name: "Komplek Wijaya Kusuma 1", type: "busstop_area", coords: [106.90529754662016, -6.229572250655908], desc: "11Q (Pulo Gebang via BKT), JAK 26 (Duren Sawit), JAK 35 (Pangkalan Jati), JAK 42 (Pondok Kelapa)" },
        { name: "Komplek Wijaya Kusuma 2", type: "busstop_area", coords: [106.90494885945503, -6.229689570956191], desc: "11Q (Kampung Melayu via BKT), JAK 26 (Rawamangun), JAK 35 (Rawamangun), JAK 42 (Kampung Melayu)" },
        { name: "Jln. Mesjid Abidin", type: "busstop_area", coords: [106.90194478535524, -6.2294549303278774], desc: "11Q (Pulo Gebang via BKT), JAK 26 (Duren Sawit)" },
        { name: "Jln. Melati Bhakti", type: "busstop_area", coords: [106.90147271657783, -6.229582916137309], desc: "11Q (Kampung Melayu via BKT), JAK 26 (Rawamangun), JAK 35 (Rawamangun), JAK 42 (Kampung Melayu)" },
        { name: "Sbr. SMPN 195", type: "busstop_area", coords: [106.90987584895811, -6.230897612797323], desc: "11P (Rusun Pondok Bambu), JAK 02 (Duren Sawit), JAK 26 (Duren Sawit)" },
        { name: "Duren Sawit", type: "busstop_area", coords: [106.91006051942696, -6.233312825764764], desc: "11P (Rusun Pondok Bambu), JAK 02 (Kampung Melayu), JAK 26 (Rawamangun)" },
        { name: "Gereja Santa Anna 1", type: "busstop_area", coords: [106.90996241323238, -6.233897982588244], desc: "11P (Walikota Jakarta Timur), JAK 02 (Duren Sawit), JAK 85 (Bintara)" },
        { name: "Gereja Santa Anna 2", type: "busstop_area", coords: [106.91017593847307, -6.234001245485681], desc: "11P (Rusun Pondok Bambu), JAK 02 (Kampung Melayu), JAK 85 (Bintara)" },
        { name: "Jln. Bambu Ori I", type: "busstop_area", coords: [106.90789641222092, -6.239066839410937], desc: "JAK 02 (Duren Sawit)" },
        { name: "Jln. Bambu Ori Raya", type: "busstop_area", coords: [106.90767654890165, -6.239117745147692], desc: "JAK 02 (Kampung Melayu)" },
        { name: "Sekolah Tunas Cemerlang", type: "busstop_area", coords: [106.90498617528901, -6.238971591297629], desc: "JAK 02 (Duren Sawit), JAK 35 (Rawamangun)" },
        { name: "Simpang Gading Raya", type: "busstop_area", coords: [106.90515343412582, -6.239048330465262], desc: "JAK 02 (Kampung Melayu), JAK 35 (Pangkalan Jati)" },
        { name: "Ps. Pondok Bambu I", type: "busstop_area", coords: [106.90241828961786, -6.238095633807914], desc: "JAK 02 (Duren Sawit)" },
        { name: "Ps. Pondok Bambu II", type: "busstop_area", coords: [106.90254991194539, -6.238175277357896], desc: "JAK 02 (Kampung Melayu)" }
    ],
    routes: [
        // BRT
        { id: "11", code: "11", mode: "brt", name: "Pulogebang - Kampung Melayu", tarif: "Rp 3.500", jam: "00.00 - 23.59 (24 Jam)", stops: ["Halte Simpang Buaran (Pemberhentian Terdekat)"], mapImage: "https://smk.transjakarta.co.id/aset/berkas/rute/11-20250102.jpg", badgeColor: "#2F4FA2" },

        // Non-BRT
        { id: "4F", code: "4F", mode: "nbrt", name: "Pinang Ranti - Pulo Gadung", tarif: "Rp 3.500", jam: "05.00 - 22.00", stops: ["Bus Stop Pangkalan Jati 1 / RS Harum / Simpang Pahlawan Revolusi 2 (Arah Pinang Ranti)", "Pospol Makasar / Simpang Kalimalang / Simpang Pahlawan Revolusi 1 (Arah Pulo Gadung)"], mapImage: "https://smk.transjakarta.co.id/aset/berkas/rute/4F-20240116.jpg", badgeColor: "#b900e2" },
        { id: "7P", code: "7P", mode: "nbrt", name: "Pondok Kelapa - Cawang Cililitan", tarif: "Rp 3.500", jam: "05.00 - 22.00", stops: ["Pangkalan Jati 1 (Arah Pondok Kelapa)", "RS Harum / Pospol Makasar (Arah Cawang Cililitan)"], mapImage: "https://smk.transjakarta.co.id/aset/berkas/rute/7P-20250901.jpeg", badgeColor: "#911d3c" },
        { id: "11Q", code: "11Q", mode: "nbrt", name: "Kampung Melayu - Pulo Gebang via BKT", tarif: "Rp 3.500 (Rp 2.000 jam 05.00-07.00)", jam: "05.00 - 22.00", stops: ["Jln. Kelurahan Raya (Arah Kp. Melayu)", "Jln. Serdang (Arah Pulo Gebang)"], mapImage: "https://smk.transjakarta.co.id/aset/berkas/rute/11Q-20240202.jpg", badgeColor: "#10c0ff" },

        // Mikrotrans - RUSUN first, then others
        { id: "11P", code: "11P", mode: "mikro", subtype: "rusun", name: "Rusun Pondok Bambu - Walikota Jakarta Timur", tarif: "Rp 0 (Wajib Kartu)", jam: "05.00 - 22.00", stops: ["Rusun Pondok Bambu (Arah Walikota Jakarta Timur)"], mapImage: "https://smk.transjakarta.co.id/aset/berkas/rute/11P-20240709.jpg", badgeColor: "#b2a5a3" },
        { id: "JAK02", code: "JAK 02", mode: "mikro", name: "Duren Sawit - Kampung Melayu", tarif: "Rp 0 (Wajib Kartu)", jam: "05.00 - 22.00", stops: ["Jln. Teluk Mandar 1 (Arah Duren Sawit)", "Jln. Teluk Mandar 2 (Arah Kp. Melayu)"], mapImage: "https://smk.transjakarta.co.id/aset/berkas/rute/115486-1712034288_fd8f5f535e5106298587.jpeg", badgeColor: "#00b0ec" },
        { id: "JAK26", code: "JAK 26", mode: "mikro", name: "Rawamangun - Duren Sawit", tarif: "Rp 0 (Wajib Kartu)", jam: "05.00 - 22.00", stops: ["Cek Peta Rute untuk detail pemberhentian"], mapImage: "https://smk.transjakarta.co.id/aset/berkas/rute/115486-1712033883_e99c8620d3b4f7520d71.jpg", badgeColor: "#00b0ec" },
        { id: "JAK85", code: "JAK 85", mode: "mikro", name: "Bintara - Cipinang Indah", tarif: "Rp 0 (Wajib Kartu)", jam: "05.00 - 22.00", stops: ["Rusun Pondok Bambu (Bintara)", "Puskesmas Duren Sawit (Arah Cipinang Indah)"], mapImage: "https://smk.transjakarta.co.id/aset/berkas/rute/JAK85-20240816.jpeg", badgeColor: "#00b0ec" },

        // Rail
        { id: "KRL", code: "KRL Commuter", mode: "rail", name: "Cikarang - Kampung Bandan", tarif: "Rp 3.000 - Rp 13.000", jam: "04.00 - 24.00", stops: ["Stasiun Buaran"], mapImage: "https://transportforjakarta.or.id/wp-content/uploads/2024/11/Peta-Rute-Commuter-Line.pdf", isPdf: true, badgeColor: "#26baed" },
        { id: "LRT", code: "LRT Jabodebek", mode: "rail", name: "Jatimulya - Dukuh Atas", tarif: "Rp 5.000 - Rp 20.000", jam: "05.22 - 23.00", stops: ["Stasiun Jatibening Baru"], mapImage: "https://transportforjakarta.or.id/wp-content/uploads/2024/11/Peta-Rute-LRT-Jabodebek.pdf", isPdf: true, badgeColor: "#006838" }
    ],
    guides: [
        {
            title: "Siapkan Kartu Uang Elektronik",
            steps: [
                "**E-Money** - Bank Mandiri",
                "**Flazz** - Bank BCA",
                "**Brizzi** - Bank BRI",
                "**TapCash** - Bank BNI",
                "**JakCard** - Bank DKI",
                "Saldo minimum **Rp 5.000,-**"
            ]
        },
        {
            title: "Alternatif Pembayaran Digital",
            steps: [
                "Gunakan **QRIS Tap** pada E-wallet yang mendukung.",
                "Saldo minimum : **Rp 5.000,-**"
            ]
        },
        {
            title: "Pantau Lokasi Bus Transjakarta",
            steps: [
                "Download aplikasi **TJ: Transjakarta** di Play Store / App Store.",
                "atau bisa gunakan **Google Maps**",
                "Gunakan fitur tracking untuk melihat posisi bus secara real-time.",
                "Cek estimasi waktu kedatangan bus di halte terdekat."
            ]
        }
    ]
};
